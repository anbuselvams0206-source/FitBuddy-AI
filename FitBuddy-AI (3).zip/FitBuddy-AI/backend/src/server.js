import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { GoogleGenerativeAI } from '@google/generative-ai';

const app = express();
const PORT = Number(process.env.PORT || 5000);
const CLIENT_ORIGIN = process.env.CLIENT_ORIGIN || 'http://localhost:5173';

app.use(cors({ origin: CLIENT_ORIGIN, credentials: false }));
app.use(express.json({ limit: '1mb' }));

const genAI = process.env.GEMINI_API_KEY
  ? new GoogleGenerativeAI(process.env.GEMINI_API_KEY)
  : null;

const fallbackPlan = (profile) => ({
  title: `${profile.goal} plan for ${profile.name || 'you'}`,
  summary: `A balanced ${profile.daysPerWeek}-day routine focused on ${profile.goal.toLowerCase()}, matched to a ${profile.experience.toLowerCase()} experience level.`,
  safety: [
    'Warm up for 5–10 minutes before training.',
    'Use controlled form and stop when pain is sharp or unusual.',
    'Take rest days and prioritize sleep, hydration, and recovery.'
  ],
  weeklyPlan: Array.from({ length: Number(profile.daysPerWeek) || 4 }, (_, index) => ({
    day: `Day ${index + 1}`,
    focus: ['Full Body', 'Upper Body', 'Lower Body', 'Conditioning'][index % 4],
    duration: '40–50 min',
    exercises: [
      { name: 'Bodyweight Squat', sets: '3', reps: '10–12', rest: '60 sec' },
      { name: 'Push-Up', sets: '3', reps: '8–12', rest: '60 sec' },
      { name: 'Dumbbell Row', sets: '3', reps: '10–12', rest: '60–90 sec' },
      { name: 'Plank', sets: '3', reps: '30–45 sec', rest: '45 sec' }
    ]
  })),
  nutrition: [
    { meal: 'Breakfast', idea: 'Oats with fruit and a protein source' },
    { meal: 'Lunch', idea: 'Rice/roti, vegetables, dal or lean protein' },
    { meal: 'Snack', idea: 'Fruit with yogurt, nuts, or a protein-rich snack' },
    { meal: 'Dinner', idea: 'Vegetables with a balanced protein and carbohydrate source' }
  ],
  habits: [
    'Drink water regularly throughout the day.',
    'Aim for consistent sleep and recovery.',
    'Track workouts and increase difficulty gradually.'
  ]
});

function sanitizePlan(raw, profile) {
  if (!raw || typeof raw !== 'object') return fallbackPlan(profile);
  return {
    title: raw.title || `${profile.goal} plan`,
    summary: raw.summary || '',
    safety: Array.isArray(raw.safety) ? raw.safety : [],
    weeklyPlan: Array.isArray(raw.weeklyPlan) ? raw.weeklyPlan : [],
    nutrition: Array.isArray(raw.nutrition) ? raw.nutrition : [],
    habits: Array.isArray(raw.habits) ? raw.habits : []
  };
}

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, geminiConfigured: Boolean(genAI) });
});

app.post('/api/generate-plan', async (req, res) => {
  const profile = req.body || {};
  const required = ['age', 'height', 'weight', 'goal', 'experience', 'daysPerWeek'];
  const missing = required.filter((key) => profile[key] === undefined || profile[key] === '');

  if (missing.length) {
    return res.status(400).json({
      error: `Missing required fields: ${missing.join(', ')}`
    });
  }

  if (!genAI) {
    return res.json({ source: 'demo', plan: fallbackPlan(profile) });
  }

  const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
  const prompt = `
You are FitBuddy AI, a fitness planning assistant.
Create a practical, safe, beginner-friendly fitness plan from this profile:
${JSON.stringify(profile, null, 2)}

Return ONLY valid JSON with this exact shape:
{
  "title": "string",
  "summary": "string",
  "safety": ["string"],
  "weeklyPlan": [
    {
      "day": "Day 1",
      "focus": "string",
      "duration": "string",
      "exercises": [
        { "name": "string", "sets": "string", "reps": "string", "rest": "string" }
      ]
    }
  ],
  "nutrition": [
    { "meal": "Breakfast", "idea": "string" }
  ],
  "habits": ["string"]
}

Keep advice general and educational. Do not diagnose conditions or prescribe medical treatment.
Avoid extreme dieting, unsafe exercise, or supplement dosing.
`;

  try {
    const result = await model.generateContent(prompt);
    const text = result.response.text().trim();
    const cleaned = text.replace(/^```json\s*/i, '').replace(/\s*```$/i, '');
    const parsed = JSON.parse(cleaned);
    return res.json({ source: 'gemini', plan: sanitizePlan(parsed, profile) });
  } catch (error) {
    console.error('Gemini error:', error);
    return res.status(502).json({
      error: 'Unable to generate the AI plan right now. Please try again or use demo mode.'
    });
  }
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: 'Internal server error.' });
});

app.listen(PORT, () => {
  console.log(`FitBuddy AI backend running on http://localhost:${PORT}`);
});
