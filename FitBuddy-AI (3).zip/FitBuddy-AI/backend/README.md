# FitBuddy AI Backend

Express API for generating personalized fitness plans.

## Endpoint

`POST /api/generate-plan`

Request body:

```json
{
  "name": "Anbu",
  "age": 20,
  "gender": "Prefer not to say",
  "height": 170,
  "weight": 70,
  "goal": "Build muscle",
  "experience": "Beginner",
  "daysPerWeek": 4,
  "equipment": "Dumbbells",
  "diet": "Non-vegetarian",
  "notes": "Prefer short sessions"
}
```

When `GEMINI_API_KEY` is configured, Gemini generates the plan. Without the key, a sample plan is returned for UI development.
