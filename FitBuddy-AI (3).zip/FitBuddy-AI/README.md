# FitBuddy AI – Fitness Plan Generator

A full-stack fitness planning app built with React + Vite on the frontend and Node.js + Express on the backend. The backend can use Google's Gemini API to generate a personalized workout and nutrition plan.

## Project structure

```text
FitBuddy-AI/
├── backend/
│   ├── src/
│   │   └── server.js
│   ├── .env.example
│   ├── package.json
│   └── README.md
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── FeatureCard.jsx
│   │   │   ├── PlanCard.jsx
│   │   │   └── ProfileForm.jsx
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   └── styles.css
│   ├── .env.example
│   ├── index.html
│   ├── package.json
│   └── vite.config.js
└── README.md
```

## Run locally

### 1. Backend

```bash
cd backend
npm install
copy .env.example .env
```

Edit `.env` and add your Gemini API key. Then:

```bash
npm run dev
```

Backend runs on `http://localhost:5000`.

### 2. Frontend

Open another terminal:

```bash
cd frontend
npm install
copy .env.example .env
npm run dev
```

Open the Vite URL shown in the terminal, usually `http://localhost:5173`.

## Environment variables

Backend `.env`:

```env
PORT=5000
GEMINI_API_KEY=your_gemini_api_key_here
CLIENT_ORIGIN=http://localhost:5173
```

Frontend `.env`:

```env
VITE_API_URL=http://localhost:5000/api
```

The app also works in demo mode when `GEMINI_API_KEY` is not set: the backend returns a deterministic sample plan so you can test the UI.
