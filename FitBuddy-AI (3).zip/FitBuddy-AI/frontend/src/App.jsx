import { useState } from 'react';
import FeatureCard from './components/FeatureCard';
import ProfileForm from './components/ProfileForm';
import PlanCard from './components/PlanCard';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

const initialProfile = {
  name: '',
  age: 20,
  gender: 'Prefer not to say',
  height: 170,
  weight: 70,
  goal: 'Build Muscle',
  experience: 'Beginner',
  daysPerWeek: '4',
  equipment: 'Dumbbells',
  diet: 'Non-vegetarian',
  notes: ''
};

export default function App() {
  const [profile, setProfile] = useState(initialProfile);
  const [plan, setPlan] = useState(null);
  const [source, setSource] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function generatePlan(event) {
    event.preventDefault();
    setLoading(true);
    setError('');
    setPlan(null);

    try {
      const response = await fetch(`${API_URL}/generate-plan`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...profile, age: Number(profile.age), height: Number(profile.height), weight: Number(profile.weight), daysPerWeek: Number(profile.daysPerWeek) })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Request failed');
      setPlan(data.plan);
      setSource(data.source);
      setTimeout(() => document.getElementById('plan')?.scrollIntoView({ behavior: 'smooth' }), 50);
    } catch (err) {
      setError(err.message || 'Could not connect to the backend.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#top">FitBuddy<span>AI</span></a>
        <a className="nav-link" href="#generator">Create Plan</a>
      </header>

      <main id="top">
        <section className="hero">
          <div className="hero-copy">
            <span className="pill">PERSONAL FITNESS ASSISTANT</span>
            <h1>Your plan.<br /><em>Built for you.</em></h1>
            <p>Tell FitBuddy AI about your goals, lifestyle, and available equipment. Get a practical workout, nutrition, and habit plan in seconds.</p>
            <a className="primary-btn hero-btn" href="#generator">Build My Plan →</a>
          </div>
          <div className="hero-visual" aria-hidden="true">
            <div className="orb orb-one" />
            <div className="orb orb-two" />
            <div className="hero-card">
              <span>Today</span>
              <strong>Full Body</strong>
              <small>45 min · 6 exercises</small>
              <div className="progress"><span /></div>
              <div className="hero-stats"><span><b>7.2k</b> steps</span><span><b>520</b> kcal</span></div>
            </div>
          </div>
        </section>

        <section className="features">
          <FeatureCard icon="✦" title="Personalized" text="Plans adapt to your goal, experience, schedule, and equipment." />
          <FeatureCard icon="⌁" title="AI-Powered" text="Gemini turns your profile into a structured, easy-to-follow plan." />
          <FeatureCard icon="↗" title="Actionable" text="Clear exercises, meal ideas, and daily habits—without the clutter." />
        </section>

        <section id="generator" className="generator-section">
          <div className="section-heading">
            <span className="eyebrow">Step 1</span>
            <h2>Tell us about you</h2>
            <p>Use realistic numbers and preferences so the generated plan is more relevant.</p>
          </div>
          <ProfileForm profile={profile} setProfile={setProfile} onSubmit={generatePlan} loading={loading} />
          {error && <div className="error-box">{error}</div>}
        </section>

        <section id="plan" className="results-section">
          {plan ? (
            <PlanCard plan={plan} source={source} />
          ) : (
            <div className="empty-state">
              <span className="empty-icon">◎</span>
              <h2>Your personalized plan will appear here</h2>
              <p>Complete the profile above and generate your FitBuddy AI plan.</p>
            </div>
          )}
        </section>
      </main>

      <footer>FitBuddy AI · Built with React, Express & Gemini</footer>
    </div>
  );
}
