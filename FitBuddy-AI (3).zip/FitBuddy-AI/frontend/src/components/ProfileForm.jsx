export default function ProfileForm({ profile, setProfile, onSubmit, loading }) {
  const update = (key) => (event) =>
    setProfile((current) => ({ ...current, [key]: event.target.value }));

  return (
    <form className="profile-form" onSubmit={onSubmit}>
      <div className="form-grid">
        <label>
          Name
          <input value={profile.name} onChange={update('name')} placeholder="Your name" />
        </label>
        <label>
          Age
          <input type="number" min="13" max="100" value={profile.age} onChange={update('age')} required />
        </label>
        <label>
          Gender
          <select value={profile.gender} onChange={update('gender')}>
            <option>Prefer not to say</option>
            <option>Female</option>
            <option>Male</option>
            <option>Other</option>
          </select>
        </label>
        <label>
          Height (cm)
          <input type="number" min="100" max="250" value={profile.height} onChange={update('height')} required />
        </label>
        <label>
          Weight (kg)
          <input type="number" min="25" max="300" value={profile.weight} onChange={update('weight')} required />
        </label>
        <label>
          Fitness goal
          <select value={profile.goal} onChange={update('goal')}>
            <option>Build Muscle</option>
            <option>Lose Weight</option>
            <option>Improve Fitness</option>
            <option>Improve Endurance</option>
            <option>Maintain Weight</option>
          </select>
        </label>
        <label>
          Experience
          <select value={profile.experience} onChange={update('experience')}>
            <option>Beginner</option>
            <option>Intermediate</option>
            <option>Advanced</option>
          </select>
        </label>
        <label>
          Days per week
          <select value={profile.daysPerWeek} onChange={update('daysPerWeek')}>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
          </select>
        </label>
        <label>
          Equipment
          <select value={profile.equipment} onChange={update('equipment')}>
            <option>No equipment</option>
            <option>Dumbbells</option>
            <option>Home gym</option>
            <option>Full gym</option>
          </select>
        </label>
        <label>
          Diet preference
          <select value={profile.diet} onChange={update('diet')}>
            <option>Non-vegetarian</option>
            <option>Vegetarian</option>
            <option>Vegan</option>
            <option>Eggitarian</option>
          </select>
        </label>
      </div>

      <label>
        Notes
        <textarea
          value={profile.notes}
          onChange={update('notes')}
          rows="4"
          placeholder="Any preferences, schedule limitations, or workout constraints..."
        />
      </label>

      <button className="primary-btn" type="submit" disabled={loading}>
        {loading ? 'Generating your plan...' : 'Generate AI Plan'}
      </button>
    </form>
  );
}
