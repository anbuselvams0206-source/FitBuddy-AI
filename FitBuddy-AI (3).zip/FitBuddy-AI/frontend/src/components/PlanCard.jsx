export default function PlanCard({ plan, source }) {
  if (!plan) return null;

  return (
    <section className="plan-section">
      <div className="plan-header">
        <div>
          <span className="eyebrow">{source === 'gemini' ? 'AI generated' : 'Demo mode'}</span>
          <h2>{plan.title}</h2>
          <p>{plan.summary}</p>
        </div>
      </div>

      <div className="section-block">
        <h3>Weekly Workout</h3>
        <div className="days-grid">
          {plan.weeklyPlan.map((day) => (
            <article className="day-card" key={day.day}>
              <div className="day-top">
                <strong>{day.day}</strong>
                <span>{day.duration}</span>
              </div>
              <h4>{day.focus}</h4>
              <div className="exercise-table">
                {day.exercises?.map((exercise) => (
                  <div className="exercise-row" key={`${day.day}-${exercise.name}`}>
                    <span>{exercise.name}</span>
                    <small>{exercise.sets} × {exercise.reps} · {exercise.rest}</small>
                  </div>
                ))}
              </div>
            </article>
          ))}
        </div>
      </div>

      <div className="two-column">
        <div className="section-block">
          <h3>Nutrition Ideas</h3>
          <div className="list-card">
            {plan.nutrition.map((item) => (
              <div className="list-item" key={item.meal}>
                <strong>{item.meal}</strong>
                <span>{item.idea}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="section-block">
          <h3>Daily Habits</h3>
          <div className="list-card">
            {plan.habits.map((habit) => <div className="check-item" key={habit}>✓ {habit}</div>)}
          </div>
        </div>
      </div>

      {plan.safety?.length > 0 && (
        <div className="safety-box">
          <h3>Safety & Recovery</h3>
          {plan.safety.map((item) => <p key={item}>• {item}</p>)}
        </div>
      )}
    </section>
  );
}
